var express = require("express");
var app = express();
var multer = require("multer");
var upload = multer({ dest: "dist/unloads/" })
var fs = require("fs");
var path = require("path");
//静态目录
app.use(express.static('./dist'));

app.all('*', function (req, res, next) {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Headers', 'Content-Type');
    res.header('Access-Control-Allow-Methods', '*');
    res.header('Content-Type', 'text/html;charset=utf-8');
    next();
});



app.get("/", function (req, res) {
    res.send("你好");
})
var userList = [];
var isLogin = false;
let loginPhone = "";//目前的登录账号
//登录接口
app.get("/login", function (req, res) {
    loginPhone = req.query.username //目前的登录账号
    console.log("登录账号==>", loginPhone);
    let { username, password } = req.query;
    if (username == "" && password == "") {
        return;
    }
    let data = userList.find(item => item.phone == username);//返回对象
    if (data && data.password == password) {
        isLogin = true;
        res.send("200");
    } else {
        res.send("201");
    }
})
//注册接口
app.get("/register", function (req, res) {
    let brief = "不妨介绍一下自己"; //自我介绍
    let backgroundImg = ""; //背景
    let headImg = "";   //头像
    let likeMovie = []; //收藏夹
    let myTicket = []; //票据
    let { phone, password, manager, passwordAgain } = req.query;
    if (manager != "" && password == passwordAgain && password != "" && phone != "") {
        if (userList.length == 0) {
            userList.push({ manager, password, phone, brief, backgroundImg, headImg, likeMovie, myTicket });
            res.send("200");
            console.log("注册列表==>", userList);
            return;
        }
        else if (userList.length != 0) {
            for (var i = 0; i < userList.length; i++) {
                if (userList[i].phone == req.query.phone) {
                    res.send("202");
                    return;
                }
                else {
                    userList.push({ manager, password, phone, brief, backgroundImg, headImg, likeMovie, myTicket });
                    res.send("200");
                    console.log("注册列表==>", userList);
                    return;
                }
            }
        }
        else {
            res.send("201")
        }
    }

})
var usermsg; //储存个人信息
//个人信息接口
app.get("/my", function (req, res) {
    if (isLogin == true) {
        let loginMsg = userList;
        for (let i = 0; i < loginMsg.length; i++) {
            if (loginMsg[i].phone == loginPhone) {
                usermsg = loginMsg[i];
            }
        }
        res.json({ code: 200, usermsg, isLogin });
    }
    if (isLogin == false) {
        res.send("202");
    }
    //console.log("my===>", usermsg);
})
//修改个人信息接口
app.get("/account", function (req, res) {
    if (isLogin == true) {
        if (usermsg.length != 0 && req.query.myNewName != "") {
            console.log(req.query)
            usermsg.manager = req.query.myNewName;
            res.json({ code: 200, usermsg })
        }
        else {
            res.send("202")
        }
    }

})
//修改简介
app.get("/brief", function (req, res) {
    if (isLogin == true) {
        if (req.query.brief != "") {
            usermsg.brief = req.query.brief;
            res.json({ code: 200, usermsg });
            //   console.log("usermsg===>", usermsg)
        }
        else {
            res.send("201")
        }
    }
    else {
        res.send("202")
    }
})
//注销接口
app.get("/logout", function (req, res) {
    if (isLogin == true) {
        isLogin = false;
        res.json({ code: 200, isLogin });
    }
    else {
        res.send("202");
    }
})
//修改密码
app.get("/password", function (req, res) {
    console.log(req.query)
    if (usermsg.password == req.query.oldPassword) {
        usermsg.password = req.query.newPassword;
        res.send("200");
    }
    else {
        res.send("201");
    }
})
//电影数据接口
var movie = [
    {
        id: 1,
        movieName: "复仇者联盟4:终结之战",
        value: 5,
        intro:
            "一声响指，宇宙间半数生命灰飞烟灭。几近绝望的复仇者们在惊奇队长（布丽·拉尔森 Brie Larson 饰）的帮助下找到灭霸（乔什·布洛林 Josh Brolin 饰）归隐之处，却得知六颗无限宝石均被销毁，希望彻底破灭。如是过了五年，迷失在量子领域的蚁人（保罗·路德 Paul Rudd 饰）意外回到现实世界，他的出现为幸存的复仇者们点燃了希望。与美国队长（克里斯·埃文斯 Chris Evans 饰）冰释前嫌的托尼（小罗伯特·唐尼 Robert Downey Jr. 饰）找到了穿越时空的方法，星散各地的超级英雄再度集结，他们分别穿越不同的时代去搜集无限宝石。而在这一过程中，平行宇宙的灭霸察觉了他们的计划。注定要载入史册的最终决战，超级英雄们为了心中恪守的信念前仆后继……",
        movieImg: "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1594819668039&di=87fa159d2d54bac6bd724261a154bee3&imgtype=0&src=http%3A%2F%2Fdingyue.ws.126.net%2F7LAVVIOaFWjXrEwFpkeRspi1CwiLvQpxIEtQHV8NO7m221553535580694compressflag.jpeg",
        protagonist:
            "小罗伯特·唐尼/克里斯·埃文斯/马克·鲁弗洛/克里斯·海姆斯沃斯/斯嘉丽·约翰逊 ",
        director: "安东尼·罗素/乔·罗素",
        price: 59,
        time: "2020/7/20",
        isLike: false,
        place: "第一放映室",
        useSeat:[]
    },
    {
        id: 2,
        movieName: "海贼王:黄金城",
        value: 4,
        intro:
            "路飞（田中真弓 配音）和他的草帽海贼团在新世界展开全新的冒险，这一次他们来到了世界上最大的娱乐城——古兰·泰佐罗。这里云集了世界各地的富豪、海盗、海军，同时也是政府承认的独立国家和非武装地带，是世界政府不可轻易染指的“绝对圣域”。被称作“黄金帝”的吉尔德·泰佐罗（山路和弘 配音）是绝对圣域的至高领导，据说吃过金金果实的他拥有常人难以想象的神奇能力，此时有条不紊地实施着雄霸天下的计划。另一方面，原打算狠捞一笔的路飞一伙落入了吉尔德·泰佐罗的金钱陷阱，他们进而被卷入了裹挟着奉献给天龙人的“天上金”以及对抗政府的革命军的巨大漩涡之中。新的争斗在所难免……",
        movieImg: "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1594819726920&di=34cd297ad7548d0358cb22449399dddc&imgtype=0&src=http%3A%2F%2Fimg1.imgtn.bdimg.com%2Fit%2Fu%3D1348326121%2C3052955258%26fm%3D214%26gp%3D0.jpg",
        protagonist: "田中真弓/中井和哉/冈村明美/山口胜平/平田广明/",
        director: "宫元宏彰",
        scriptwriter: "黑岩勉 / 尾田荣一郎",
        isLike: false,
        price: 49,
        time: "2020/7/20",
        place: "第二放映室",
        useSeat:[]
    },
    {
        id: 3,
        movieName: "哪吒之魔童降世",
        value: 4,
        intro:
            "天地灵气孕育出一颗能量巨大的混元珠，元始天尊将混元珠提炼成灵珠和魔丸，灵珠投胎为人，助周伐纣时可堪大用；而魔丸则会诞出魔王，为祸人间。元始天尊启动了天劫咒语，3年后天雷将会降临，摧毁魔丸。太乙受命将灵珠托生于陈塘关李靖家的儿子哪吒身上。然而阴差阳错，灵珠和魔丸竟然被掉包。本应是灵珠英雄的哪吒却成了混世大魔王。调皮捣蛋顽劣不堪的哪吒却徒有一颗做英雄的心。然而面对众人对魔丸的误解和即将来临的天雷的降临，哪吒是否命中注定会立地成魔？他将何去何从？",
        movieImg: "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1594820471645&di=0755b66f0431cd9e269c8bb43edee1e7&imgtype=0&src=http%3A%2F%2F5b0988e595225.cdn.sohucs.com%2Fq_70%2Cc_zoom%2Cw_640%2Fimages%2F20190804%2F5c51e65226dd4132a6e14426ac607cc8.jpeg",
        protagonist: "吕艳婷/囧森瑟夫/瀚墨/陈浩/绿绮/",
        director: "饺子",
        scriptwriter: "饺子/易巧/魏芸芸",
        price: 49,
        time: "2020/7/19",
        isLike: false,
        place: "第三放映室",
        useSeat:[]
    },
    {
        id: 4,
        movieName: "唐人街探案3",
        value: 4,
        intro:
            "该片讲述了“曼谷夺金杀人案”“纽约五行连环杀人案”后，“唐人街神探组合”唐仁，秦风被野田昊请到东京，调查一桩离奇的谋杀案的故事。继曼谷、纽约之后，东京再出大案。唐人街神探唐仁（王宝强饰）、秦风（刘昊然饰）受侦探野田昊（妻夫木聪饰）的邀请前往破案。“CRIMASTER世界侦探排行榜”中的侦探们闻讯后也齐聚东京，加入挑战，而排名第一Q的现身，让这个大案更加扑朔迷离，一场亚洲最强神探之间的较量即将爆笑展开……",
        movieImg: "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1594820174123&di=da86041696d8b837883a5241521c5db9&imgtype=0&src=http%3A%2F%2Fpic-bucket.ws.126.net%2Fphoto%2F0003%2F2020-01-07%2FF29FRM3H3LF60003NOS.jpg",
        protagonist: " 王宝强/刘昊然/妻夫木聪/托尼·贾/长泽雅美/",
        director: "陈思诚",
        scriptwriter: " 陈思诚/张淳/刘吾驷/莲舟/严以宁",
        price: 59,
        time: "2020/7/18",
        islike: false,
        place: "第四放映室",
        useSeat:[]
    },
    {
        id: 5,
        movieName: "姜子牙",
        value: 5,
        intro:
            "动画电影《姜子牙》的故事发生于封神大战之后。昆仑弟子姜子牙，率领众神战胜狐妖，推翻了残暴的商王朝，赢得封神大战的胜利，即将受封为众神之长。在巅峰时刻，他却因一时之过被贬下凡间。失去神力，被世人唾弃。为重回昆仑，姜子牙踏上旅途。在战后的废墟之上，他重新找到了自我，也发现了当年一切的真相。该片原定于2020年1月25（大年初一）在中国内地上映。1月23日，因新冠病毒疫情爆发，片方宣布退出春节档，择日上映。",
        movieImg: "https://ss0.bdstatic.com/70cFuHSh_Q1YnxGkpoWK1HF6hhy/it/u=1039592201,3384601005&fm=15&gp=0.jpg",
        protagonist: "姜广涛/季冠霖/郑希/图特哈蒙/杨凝/ ",
        director: "程腾/李炜",
        scriptwriter: "程腾/李炜",
        price: 60,
        time: "2020/7/16",
        isLike: false,
        place: "第五放映室",
        useSeat:[]
    },
    {
        id: 6,
        movieName: "纯洁心灵·逐梦演艺圈",
        value: 1,
        intro:
            "海亚影视学院（虚构）近些年已经跻身国内著名影视院校的行列，其表演系2013级本科班，学生形象、艺术条件都格外突出，从入校伊始就备受学校师生关注，被誉为“准明星班”。班主任文天阳年青英俊，刚刚硕士毕业留校，认真负责。班里共有17名学生，8男9女，家庭背景、成长经历、性格各异：有的学生家里条件优越，有奢华海边别墅、游艇与跑车；有的学生是普通工薪阶层的子女；还有学生来自落后偏远山区的少数民族；还有学生是单亲家庭的问题子女……他们热情澎湃，都在自己最美好的青春年华，为自己的美好梦想奋斗着。演员是一个相对被动的职业，经常需要见组和推销自己，学习表演专业的学生也难免要比普通专业学生与社会有更多、更早的接触。城市中有着很多诱惑，影视圈也同样复杂，他们的青春美貌也吸引了形形色色的人士们的目光。",
        movieImg: "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1594820277666&di=5d2837ebd0ea29405c50400b1668c349&imgtype=0&src=http%3A%2F%2Fe0.ifengimg.com%2F09%2F2019%2F0407%2F98202D295891EC213EC16AB7EDC841E58A444BF4_size289_w1080_h1610.jpeg",
        protagonist: " 朱一文/李彦漫/陈思瀚/张芷榕/毕志飞/ ",
        director: "毕志飞",
        scriptwriter: "毕志飞",
        price: 39,
        time: "2020/7/15",
        place: "第六放映室",
        isLike: false,
        useSeat:[]
    }
];
app.get("/movieList", (req, res) => {
    if (isLogin == true) {
        for (var i = 0; i < userList.length; i++) {
            if (userList[i].phone == loginPhone) {
                userList[i].likeMovie = movie;
                let result = userList[i].likeMovie;
                res.json({ code: 200, result });
            }
        }

    }
    else {
        res.send("201")
    }
})
//收藏
app.get("/like", function (req, res) {
    if (isLogin == false) {
        res.send("202")
    }
    else {
        for (var i = 0; i < userList.length; i++) {
            if (userList[i].phone == loginPhone) {
                for (var j = 0; j < userList[i].likeMovie.length; j++) {
                    if (userList[i].likeMovie[j].id == req.query.movieId && userList[i].likeMovie[j].isLike == false) {
                        let _movie = userList[i].likeMovie;
                        res.json({
                            code: 200,
                            isLike: _movie[j].isLike = true
                        })
                    }
                    else if (userList[i].likeMovie[j].id == req.query.movieId && userList[i].likeMovie[j].isLike == true) {
                        let _movie = userList[i].likeMovie;
                        res.json({
                            code: 201,
                            isLike: _movie[j].isLike = false
                        })
                    }
                }
            }
        }

    }
})
//详情页
app.get("/detail", function (req, res) {
    if (isLogin == false) {
        res.send("201")
    }
    else {
        res.send("200")
        for (var i = 0; i < userList.length; i++) {
            if (userList[i].phone == loginPhone) {
                userList[i].myTicket.push(req.query)
                // console.log(userList[i].myTicket)
            }
        }
    }
})
//我的影票
app.get("/myTicket", function (req, res) {
    if (isLogin == true) {
        for (var i = 0; i < userList.length; i++) {
            if (userList[i].phone == loginPhone) {
                res.json({
                    code: 200,
                    myTicket: userList[i].myTicket
                })
                console.log(userList[i].myTicket)
            }
        }
    }
})
//更换头像及背景
app.post("/upload", upload.single("file"), function (req, res, next) {
    if (isLogin == true) {
        let file = req.file;
        var uploads = file.path;
        let ext = path.extname(file.originalname);//获取文件后缀
        let newName = "" + (new Date().getTime()) + Math.round(Math.random() * 10000) + ext;//随机命名
        let newPath = "/dist/img/" + newName; //新路径
        let fileData = fs.readFileSync(uploads);
        fs.writeFileSync(__dirname + newPath, fileData);
        usermsg.headImg = newName; //录入
        console.log("usermsg==>",usermsg,usermsg.headImg)
        res.json({
            code: 200,
            newName: newName
        })
    }
    else {
        res.json({
            code: 201,
            message: "请先登录"
        })
    }
})
app.post("/uploadBackgroundImg", upload.single("file"), function (req, res, next) {
    if (isLogin == true) {
        let file = req.file;
        var uploads = file.path;
        let ext = path.extname(file.originalname);//获取文件后缀
        let newName = "" + (new Date().getTime()) + Math.round(Math.random() * 10000) + ext;//随机命名
        let newPath = "/dist/img/" + newName; //新路径
        let fileData = fs.readFileSync(uploads);
        fs.writeFileSync(__dirname + newPath, fileData);
        usermsg.backgroundImg = newName; //录入背景图片
        console.log("usermsg==>",usermsg,usermsg.backgroundImg)
        res.json({
            code: 200,
            newName: newName
        })
    }
    else {
        res.json({
            code: 201,
            message: "请先登录"
        })
    }
})

//影视讯息
var request = require('request');
var MovieList = [];
app.get("/moviereview", function (req, res) {
    let value = req.query.value
    if (value != "") {
        request.get(`http://v.juhe.cn/movie/index?key=c4009799d19cc38986e3482ad3eb8b58&title=${encodeURI(value)}&smode=0`, function (err, response, body) {
            MovieList = []
            MovieList.push(body);
            if (JSON.parse(MovieList[0]).error_code != 0) {
                res.send("201");
            }
            console.log(JSON.parse(MovieList[0]).error_code)
            res.json({ code: 200, MovieList })
        })
    }
    else {
        res.send("201");
    }
})
app.listen(3000, "127.0.0.1", () => {
    console.log("请访问:http://127.0.0.1:3000");
})
