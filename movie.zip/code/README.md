# 项目名称：影视世界

## 项目简介:

    该项目为vue移动端项目，其功能包括登录注册，登录后通过选择影院热映电影，进入选择页面，选定座位后可以确认订票，在个人信息的我的订票页面可以查看购票信息；此外还可以通过收藏电影，在个人页的收藏页看到收藏项；在个人页也可以对个人信息进行修改，包括修改头像，名称，简介还有背景等等，在安全页可以修改密码；通过搜索页可以搜索其他电影信息，支持模糊搜索；
### 主要项目依赖

    $npm install swiper --save-dev 安装swiper
    $npm install axios --save   安装axios
    $npm install vant -S 安装vant
  
### 项目后台：

    后台使用node.js及其Express框架；
    主要安装依赖 
    $npm install express -save; 
    $npm install request --save;

### 项目运行
    加载依赖 cnpm install 
    后台运行 $node index.js；
    访问 127.0.0.1:3000
